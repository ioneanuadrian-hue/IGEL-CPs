# Slot Analyzer Pro — prototip Android 0.1

Acesta este un proiect de pornire Android Studio, nu un APK gata instalabil.

## Ce face
- Cere permisiunea oficială Android MediaProjection pentru captură de ecran.
- Rulează capturarea într-un serviciu foreground cu notificare persistentă.
- Aplică ML Kit OCR local pentru a extrage textul vizibil.
- Afișează textul recunoscut în aplicație.

## Ce NU face
- Nu modifică aplicațiile LasVegas.ro sau Milion.ro.
- Nu ocolește protecțiile aplicațiilor și nu ascunde capturarea.
- Nu prezice rezultate RNG și nu determină când va plăti un slot.
- Nu trimite capturi către server.

## Deschidere
1. Instalează Android Studio.
2. Deschide folderul `SlotAnalyzerPro`.
3. Lasă Gradle să sincronizeze dependențele.
4. Rulează pe telefon cu USB debugging activat.
5. Apasă „Pornește analiza ecranului” și acceptă dialogul Android de captură.

## Limitări importante
- Android cere acordul utilizatorului pentru fiecare sesiune de captură.
- Unele aplicații folosesc protecția `FLAG_SECURE`; în acest caz ecranul poate apărea negru sau capturarea poate fi blocată. Prototipul nu încearcă să ocolească această protecție.
- OCR-ul este doar primul pas. Urmează să adăugăm identificarea câmpurilor (miză, câștig, sold), corectarea manuală și calculul statistic.
- Valorile citite automat trebuie validate. OCR poate confunda cifre și separatori zecimali.

## Compatibilitate
Proiect configurat pentru compileSdk 35, minSdk 26. Testarea finală trebuie făcută pe versiunea Android/One UI instalată pe telefon.
