package com.example.slotanalyzerpro

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var output: TextView

    private val projectionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val intent = Intent(this, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_START
                    putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(CaptureService.EXTRA_DATA, result.data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                else startService(intent)
                status.text = "Captură activă — Android afișează notificarea de captură."
            } else {
                status.text = "Captura nu a fost autorizată."
            }
        }

    private val textReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val recognized = intent?.getStringExtra(CaptureService.EXTRA_TEXT).orEmpty()
            if (recognized.isNotBlank()) {
                output.text = "Text recunoscut:\n$recognized\n\n" +
                    "Notă: valorile sunt citite din imagine; verifică-le înainte de a le salva."
            }
        }
    }

    @Suppress("DEPRECATION")\n    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply { textSize = 16f; text = "Captura este oprită." }
        output = TextView(this).apply { textSize = 14f; text = "Aici vor apărea informațiile OCR." }

        val start = Button(this).apply {
            text = "Pornește analiza ecranului"
            setOnClickListener {
                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(manager.createScreenCaptureIntent())
            }
        }
        val stop = Button(this).apply {
            text = "Oprește analiza"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "Captura a fost oprită."
            }
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
            setBackgroundColor(Color.WHITE)
            addView(TextView(this@MainActivity).apply {
                text = "SLOT ANALYZER PRO\nVersiune prototip 0.1"
                textSize = 22f
            })
            addView(TextView(this@MainActivity).apply {
                text = "\nAnaliză locală a informațiilor vizibile pe ecran."
                textSize = 15f
            })
            addView(start)
            addView(stop)
            addView(status)
            addView(TextView(this@MainActivity).apply { text = "\nRezultate OCR:"; textSize = 18f })
            addView(output)
            addView(TextView(this@MainActivity).apply {
                text = "\nAceastă aplicație nu controlează sloturile, nu modifică jocurile și nu prezice rotiri. Captura necesită acordul Android și poate fi blocată de aplicația sursă."
                textSize = 12f
            })
        }
        setContentView(ScrollView(this).apply { addView(content) })

        val filter = IntentFilter(CaptureService.ACTION_OCR_RESULT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(textReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(textReceiver, filter)
    }

    override fun onDestroy() {
        try { unregisterReceiver(textReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
